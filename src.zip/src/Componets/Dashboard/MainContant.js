import React from 'react'

const MainContant = () => {
  return (
    <div>MainContant</div>
  )
}

export default MainContant