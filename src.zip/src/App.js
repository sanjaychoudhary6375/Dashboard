
import './App.css';
import Dashboard from './Componets/Dashboard/Dashboard';

function App() {
  return (
    <>
      <Dashboard />
    </>
  );
}

export default App;
